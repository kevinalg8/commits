function calculo(){
    compra = parseInt(window.document.forms["f1"]["vCompra"].value)
    iva = compra * 0.19
    descuento = compra * 0.05
    total = (compra - descuento) + iva
    window.document.forms["f1"]["Iva"].value = iva
    window.document.forms["f1"]["Descuento"].value = descuento
    window.document.forms["f1"]["Total"].value = total
}
window.alert("Bienvenidos")
